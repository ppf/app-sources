<?php
/*
 Plugin Name: Nexcess BigCommerce OAuth Connector
 */

add_filter('bigcommerce/oauth_connector/url', function() {
  return 'https://wp-login.bigcommerce.com/nexcess';
});
