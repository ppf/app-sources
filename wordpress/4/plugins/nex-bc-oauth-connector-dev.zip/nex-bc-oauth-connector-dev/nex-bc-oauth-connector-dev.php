<?php
/*
 Plugin Name: Nexcess BigCommerce OAuth Connector (Dev)
 */

add_filter('bigcommerce/oauth_connector/url', function() {
  return 'https://wp-login.bigcommerce.com/nexcess-staging';
});
