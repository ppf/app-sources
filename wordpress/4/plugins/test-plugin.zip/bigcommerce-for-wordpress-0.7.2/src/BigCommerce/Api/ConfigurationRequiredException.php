<?php


namespace BigCommerce\Api;


use BigCommerce\Api\v3\ApiException;

class ConfigurationRequiredException extends ApiException {}