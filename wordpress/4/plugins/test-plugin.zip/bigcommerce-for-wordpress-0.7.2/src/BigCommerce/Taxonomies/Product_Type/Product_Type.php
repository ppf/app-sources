<?php


namespace BigCommerce\Taxonomies\Product_Type;


class Product_Type {
	const NAME = 'bigcommerce_product_type';
}