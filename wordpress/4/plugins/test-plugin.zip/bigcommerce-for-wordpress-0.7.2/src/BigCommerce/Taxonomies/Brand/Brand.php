<?php


namespace BigCommerce\Taxonomies\Brand;


class Brand {
	const NAME = 'bigcommerce_brand';
}