<?php


namespace BigCommerce\Taxonomies\Availability;


class Availability {
	const NAME = 'bigcommerce_availability';
}