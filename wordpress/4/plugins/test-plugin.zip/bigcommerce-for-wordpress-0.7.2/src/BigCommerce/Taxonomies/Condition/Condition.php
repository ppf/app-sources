<?php


namespace BigCommerce\Taxonomies\Condition;


class Condition {
	const NAME = 'bigcommerce_condition';
}