<?php


namespace BigCommerce\Taxonomies\Product_Category;


class Product_Category {
	const NAME = 'bigcommerce_category';
}