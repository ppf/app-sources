<?php

namespace BigCommerce\Accounts\Roles;

interface Role {
	public function get_id();

	public function get_label();
}
