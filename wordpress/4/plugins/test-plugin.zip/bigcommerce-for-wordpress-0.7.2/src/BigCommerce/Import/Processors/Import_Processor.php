<?php


namespace BigCommerce\Import\Processors;


interface Import_Processor {
	public function run();
}