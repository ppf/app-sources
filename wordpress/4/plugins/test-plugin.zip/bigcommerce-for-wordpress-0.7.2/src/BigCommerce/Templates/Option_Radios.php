<?php


namespace BigCommerce\Templates;

class Option_Radios extends Option_Type {

	protected $template = 'components/option-radios.php';

}