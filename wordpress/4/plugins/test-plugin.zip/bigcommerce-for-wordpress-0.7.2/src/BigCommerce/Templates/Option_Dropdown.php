<?php


namespace BigCommerce\Templates;

class Option_Dropdown extends Option_Type {

	protected $template = 'components/option-dropdown.php';

}