<?php


namespace BigCommerce\Templates;

class Option_Rectangles extends Option_Type {

	protected $template = 'components/option-rectangles.php';

}