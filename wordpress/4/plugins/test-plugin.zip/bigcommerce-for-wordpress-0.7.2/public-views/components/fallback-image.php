<?php

/**
 * Renders the fallback image for products with no featured image
 * when the site does not have a default featured image set
 *
 * @var string $image
 */

echo $image;