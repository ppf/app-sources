
export default {
	desktop_initialized: false,
	is_desktop: false,
	is_mobile: false,
	mobile_initialized: false,
	v_height: 0,
	v_width: 0,
};
