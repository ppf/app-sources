export const NLS = window.bigcommerce_i18n || {};
