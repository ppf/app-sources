/**
 * @template Product Message
 */

export const productMessage = message => (`<span class="bc-product-form__message bc-alert bc-alert--info">${message}</span>`);
