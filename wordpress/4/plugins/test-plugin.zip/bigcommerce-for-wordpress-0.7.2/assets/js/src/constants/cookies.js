
export const CART_ID_COOKIE_NAME = 'bigcommerce_cart_id';
export const CART_ITEM_COUNT_COOKIE = 'bigcommerce_cart_item_count';
export const CART_ITEM_COUNT_KEY = 'bigcommerce_current_cart_item_count';
