// @flow
/**
 * @module
 * @exports plugins
 * @description Kicks in any third party plugins that operate on
 * a sitewide basis.
 */

const plugins = () => {
	// initialize global external plugins here
};

export default plugins;
