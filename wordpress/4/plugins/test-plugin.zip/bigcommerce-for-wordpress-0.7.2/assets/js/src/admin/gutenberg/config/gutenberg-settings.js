export const gutenbergconfig = window.bigcommerce_gutenberg_config || {};

export const GUTENBERG_BLOCKS = gutenbergconfig.blocks || {};
export const GUTENBERG_PRODUCTS = GUTENBERG_BLOCKS['bigcommerce/products'] || {};
