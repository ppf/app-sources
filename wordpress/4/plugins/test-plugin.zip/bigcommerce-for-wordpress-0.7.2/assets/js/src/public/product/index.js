/**
 * @module Product Variants.
 */

import variants from './variants';

const init = () => {
	variants();
};

export default init;
