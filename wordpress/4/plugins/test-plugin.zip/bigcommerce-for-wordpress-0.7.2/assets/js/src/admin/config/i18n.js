export const I18N = window.bigcommerce_admin_i18n || {};
