// breakpoint settings

export const MOBILE_BREAKPOINT = 768;
export const FULL_BREAKPOINT = 960;
