
export default {
	isFetching: false,
};
