// Mock envs
global.__DEV__ = false;
global.__TEST__ = true;
